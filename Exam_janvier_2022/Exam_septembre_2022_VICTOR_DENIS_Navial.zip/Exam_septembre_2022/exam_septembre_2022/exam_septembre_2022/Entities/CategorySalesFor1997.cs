﻿using System;
using System.Collections.Generic;

namespace exam_septembre_2022.Entities;

public partial class CategorySalesFor1997
{
    public string CategoryName { get; set; } = null!;

    public decimal? CategorySales { get; set; }
}
