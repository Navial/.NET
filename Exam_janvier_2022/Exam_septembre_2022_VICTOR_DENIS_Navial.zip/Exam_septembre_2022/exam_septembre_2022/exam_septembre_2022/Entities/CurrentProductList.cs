﻿using System;
using System.Collections.Generic;

namespace exam_septembre_2022.Entities;

public partial class CurrentProductList
{
    public int ProductId { get; set; }

    public string ProductName { get; set; } = null!;
}
