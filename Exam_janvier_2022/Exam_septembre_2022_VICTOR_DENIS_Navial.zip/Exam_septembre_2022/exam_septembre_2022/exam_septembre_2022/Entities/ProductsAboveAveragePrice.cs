﻿using System;
using System.Collections.Generic;

namespace exam_septembre_2022.Entities;

public partial class ProductsAboveAveragePrice
{
    public string ProductName { get; set; } = null!;

    public decimal? UnitPrice { get; set; }
}
